double myadd(double, double);
double mysub(double, double);
double mymul(double, double);
double mydiv(double, double);
